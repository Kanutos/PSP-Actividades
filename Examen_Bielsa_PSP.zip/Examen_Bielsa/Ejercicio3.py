'''EJERCICIO3(3 puntos + 0,5opcional)
Usando procesos, abre tres procesos,cada uno de los cuales debe….
	P1: debe abrir el bloc de notas/editor de texto del sistema que uses
	P2: debes esperar 5 segundos para cambiar la prioridad de P1
	P3: se lanza 2 segundos después de P2 y mata a P1 al instante

	¿Qué es lo que ocurre durante la ejecución?
        - Cambia de terminal propio de VC a terminal de Windows, Cuando lo ejecutamos podemos escribir en el terminal correctamente, hasta que
        pasan los 5 sec y cambia la prioridad, entonces como ha iniciado el terminal en un directorio no permite rutas UNC, asi que regresa de maner
        predeterminada al directorio Windows.

    ¿Termina el programa correctamente?
    -No,no termina, lo deja abierto y pasa bruscamente de windows a linux al darle la prioridad, sin cerrar el proceso abierto
    
    ¿Cómo podrías solucionarlo?
    - Si quisieramos continuar usando la terminal, quitarle el tiempo de espera para que no priorize, o realizando un lock() para que no saltara
    al siguiente proceso sin antes terminar el proceso creado
OPCIONAL +0,5: 
    ¿Qué mecanismo de los estudiados te permitiría sincronizar la muerte de P1?Describe  todo lo que se te ocurra al respecto
    -A traves del mutiprocessing manager por ejemplo, ya que al ser procesos corren dentro del mismo hilo, y tienen acceso al mismo espacio de la RAM
    los hilos guardarian la informacion en ubicaciones diferentes y seria mas dificil de gestionar el paso de informacion
'''	

import os
import time
import subprocess
from multiprocessing import Process

# Abrimos cmd 
def abrir_terminal():
    subprocess.run(["cmd.exe"]) 

# Cambia prioridad a P1 despues de 5 sec
def cambia_prioridad():
    time.sleep(5)
    
# Mata proceso
def kill_proceso(p):
    time.sleep(7)  
    p.terminate()

def main():
    p1 = Process(target=abrir_terminal)
    p1.start()

    p2 = Process(target=cambia_prioridad)
    p2.start()

    p3 = Process(target=kill_proceso, args=(p1,))
    p3.start()

    p1.join()
    p2.join()
    p3.join()

if __name__ == "__main__":
    main()