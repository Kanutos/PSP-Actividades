'''Implementa en python un código de Productor Consumidor mediante cola 
sincronizada tal que:
-El productor produce números enteros mayor que 100 y menor que 500,
 el tiempo de espera entre la generación de un número y otro es de PT 
 segundos
-El consumidor lee X números de la cola de golpe, calcula la multiplicación de 
esos X números .(1 punto).el tiempo de espera entre la lectura de X elementos 
cola y la siguiente lectura de los siguientes X elementos es de  CT segundos 

Prueba el algoritmo con los distintos casos usando una relación de productor:
consumidor de     
1:1 con PT=1  CT=4 y X=3 (0,5 puntos)
4:2 con PT=2  CT=2 y X=2 (0,5 puntos)
2:6 con PT=1  CT=10 y X=4 (0,5 puntos)
NOTA DAR UN PEQUEÑO TIEMPO ENTRE EL START DE CADA CONSUMIDOR Y/O PRODUCTOR Y EL SIGUIENTE PARA PODER VER BIEN LOS MENSAJES DEL PRINT'''

import threading
import queue
import time
import random

def producer(q, PT):
    while True:
        # Produce aleatorio 100 and 500
        item = random.randint(100, 500)
        print(f"Productor pproduce: {item}")
        q.put(item)
        time.sleep(PT)

def consumer(q, X, CT):
    while True:
        product = 1
        for _ in range(100,500):
            item = q.get()
            product *= item
            print(f"Consumidor gasta: {item}")
        
        print(f"Resultado de los {X} numeros: {product}")
        
        time.sleep(5,10)

def start_threads(num_producers, num_consumers, PT, CT, X):
    q = queue.Queue()

    producer_threads = [threading.Thread(target=producer, args=(q, PT)) for _ in range(num_producers)]
    consumer_threads = [threading.Thread(target=consumer, args=(q, X, CT)) for _ in range(num_consumers)]

    for t in producer_threads + consumer_threads:
        t.start()
        time.sleep(0.1)  # Small delay to see the print messages clearly

    for t in producer_threads + consumer_threads:
        t.join()

#CASO 1
start_threads(num_producers=1, num_consumers=1, PT=1, CT=4, X=3)

#CASO 2
start_threads(num_producers=4, num_consumers=2, PT=2, CT=2, X=2)

#CASO 3
start_threads(num_producers=2, num_consumers=6, PT=1, CT=10, X=4)
