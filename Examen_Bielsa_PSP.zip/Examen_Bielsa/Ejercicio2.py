'''EJERCICIO 2:
Dado el siguiente código hazlo multihilo(0,5 puntos), consigue que la 
información pueda aparecer ordenada por pantalla y en el fichero se escriba de 
manera ordenada(2 puntos)'''

''' file_name = os.path.join(tempfile.gettempdir(), os.urandom(24).hex())

def code(name):
       time.sleep(10)
       with open(file_name, 'w') as f:
             print("guardando en "+file_name)
             f.write("codigo limpio fue escrito por "+str(name)) 
       subprocess.run(["ping", "google.com"]) '''

import os
import tempfile
import time
import subprocess
from threading import Thread

file_name = os.path.join(tempfile.gettempdir(), os.urandom(24).hex())
name="Juanito"
def code(name):
      time.sleep(10)
with open(file_name, 'w') as f:
      print("guardando en "+file_name)
      f.write("codigo limpio fue escrito por "+str(name)) 
subprocess.run(["ping", "-w 4", "google.com"])

t1 = Thread(target=code, args=("Thread 1",))
t2 = Thread(target=code, args=("Thread 2",))

t1.start()
t2.start()

t1.join()
t2.join()
      